export interface FormTemplate {
    id: number;
    name: string;
    fields: any[];
  }
  