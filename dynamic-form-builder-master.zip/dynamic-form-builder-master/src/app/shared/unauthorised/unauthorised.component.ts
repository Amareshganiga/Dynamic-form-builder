import { Component } from '@angular/core';

@Component({
  selector: 'app-unauthorised',
  standalone: true,
  imports: [],
  templateUrl: './unauthorised.component.html',
  styleUrl: './unauthorised.component.scss'
})
export class UnauthorisedComponent {

}
